/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ice_task_4;

import java.util.Scanner;
/**
 *
 * @author Nasi
 */
public class ICE_task_4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}


// 1. Interface
interface iStaff {
    int getStaffNumber();
    String getStaffLocation();
    String getStaffHiringProcess();
}

// 2. Abstract Class
abstract class Staff implements iStaff {
    protected int staffNumber;
    protected String staffLocation;

    public Staff(int staffNumber, String staffLocation) {
        this.staffNumber = staffNumber;
        this.staffLocation = staffLocation;
    }

    @Override
    public int getStaffNumber() {
        return staffNumber;
    }

    @Override
    public String getStaffLocation() {
        return staffLocation;
    }
}

// 3. Subclass
class StaffHiring extends Staff {

    public StaffHiring(int staffNumber, String staffLocation) {
        super(staffNumber, staffLocation);
    }

    @Override
    public String getStaffHiringProcess() {
        if (staffNumber < 20) {
            return "YES";
        } else {
            return "NO";
        }
    }

    public void printStaffHiring() {
        System.out.println("STAFF HIRING REPORT");
        System.out.println("*******************");
        System.out.println("LOCATION: " + getStaffLocation());
        System.out.println("STAFF NUMBER: " + getStaffNumber());
        System.out.println("HIRE STAFF: " + getStaffHiringProcess());
    }
}

// 4. Execution / Main Class (Must match the file name: UseStaff.java)
public class UseStaff {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the current staff number: ");
        int staffNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        System.out.print("Enter the staff hiring location: ");
        String location = scanner.nextLine();

        System.out.println();

        // Instantiate StaffHiring and print report
        StaffHiring staffHiring = new StaffHiring(staffNumber, location);
        staffHiring.printStaffHiring();

        scanner.close();
    }
}